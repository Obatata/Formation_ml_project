import pandas as pd

df = pd.read_csv("test.csv")
print(df.dtypes)
print()
print(df.head())