#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import  setup


setup(
    name="heart_disease_classification",
    version="1.0.0",
    include_package_data=True,
    license="BSD-3",

)